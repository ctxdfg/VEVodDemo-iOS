
#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
@class LCScreenRecorder;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LCScreenRecorderStatus) {
    LCScreenRecorderStatus_Started,
    LCScreenRecorderStatus_Recording,
    LCScreenRecorderStatus_Finished,
    LCScreenRecorderStatus_Failed
};

@protocol LCScreenRecorderProtocol <NSObject>
- (void)screenRecorder:(LCScreenRecorder *)recorder didStatusChanged:(LCScreenRecorderStatus)status;
- (void)screenRecorder:(LCScreenRecorder *)recorder didRecordingFinished:(NSURL *)path error:(NSError*)error;
@end

@interface LCScreenRecorder : NSObject
@property (nonatomic,   weak) id<LCScreenRecorderProtocol> delegate;
@property (nonatomic,   copy) NSString  *outputPath;
@property (nonatomic, assign) uint8_t   frameRate;
@property (nonatomic, assign) CGSize    outputSize;
@property (nonatomic, assign) NSInteger bitrate;

- (instancetype)initWithLiveCore:(id)engine;

- (BOOL)startRecordingWithImageCallback:(void(^)(CVPixelBufferRef buffer, CMTime pts))callback;
- (BOOL)startScreenRecordingWithCaptureCallback:(void (^)(CVPixelBufferRef _Nonnull, CMTime))callback API_AVAILABLE(ios(11.0)) DEPRECATED_MSG_ATTRIBUTE("will be deleted");


typedef struct LCAudioFrame {
    int32_t             mSampleRate;        
    int16_t             mSamplesPerChannel; 
    uint8_t             mNumberOfChannels;  
    uint8_t             mBytesPerSample;    
    
    void                *mData;
    
    int64_t             mPresentationTimeStamp;
    int32_t             mTimeScale;
} LCAudioFrame;

- (BOOL)setAudioFormat:(AudioStreamBasicDescription)asbd;
- (void)pushVideoBuffer:(CMSampleBufferRef)buffer DEPRECATED_MSG_ATTRIBUTE("will be deleted");

- (void)setMasterLayer:(int)layerId DEPRECATED_MSG_ATTRIBUTE("will be deleted");

- (void)setContainerView:(UIView *)view;
- (void)setSubview:(UIView *)view enable:(BOOL)enable DEPRECATED_MSG_ATTRIBUTE("will be deleted");

- (void)registerRenderWithView:(UIView *)view uid:(NSString *)uid DEPRECATED_MSG_ATTRIBUTE("will be delete");
- (void)updateLayoutForView:(UIView *)renderView uid:(NSString *)uid DEPRECATED_MSG_ATTRIBUTE("will be delete");;
- (void)shouldUpdateLayout DEPRECATED_MSG_ATTRIBUTE("will be delete");;
@property (nonatomic, copy) void(^bufferCallback)(CVPixelBufferRef buffer, CMTime timeInfo);
@property(nonatomic) float elapse;
@property (nonatomic) BOOL canDrawInBackground;
- (void)stopRecording;
- (void)cancelRecording;
- (UIImage *)takeShotForView:(UIView *)view;
- (BOOL)isRecording;
@end

NS_ASSUME_NONNULL_END
