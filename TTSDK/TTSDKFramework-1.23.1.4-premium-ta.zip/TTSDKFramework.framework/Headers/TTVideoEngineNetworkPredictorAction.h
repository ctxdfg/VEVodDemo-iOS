//
//  TTVideoEngineNetworkPredictorAction.h
//  TTVideoEngine
//
//  Created by shen chen on 2021/7/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol TTVideoEngineNetworkPredictorAction <NSObject>

+ (CGFloat)getPredictSpeed;
+ (CGFloat)getAveragePredictSpeed;
+ (CGFloat)getAverageDownLoadSpeed;
+ (CGFloat)getSpeedConfidence;
+ (CGFloat)getDownLoadSpeed;
- (void)setSinglePredictSpeedTimeIntervalWithHeader:(NSMutableDictionary *)headerDic;

@end

NS_ASSUME_NONNULL_END
