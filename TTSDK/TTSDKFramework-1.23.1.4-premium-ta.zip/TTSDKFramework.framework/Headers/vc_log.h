//
// Created by 黄清 on 4/19/21.
//

#ifndef PRELOAD_VC_LOG_H
#define PRELOAD_VC_LOG_H
#pragma once
#include "json.h"
#include "vc_base.h"
#include "vc_event_listener.h"
#include <memory>

VC_NAMESPACE_BEGIN

typedef enum : int {
    PlayTaskOperatePause = 1,
    PlayTaskOperateResume = 2,
} VCPlayTaskOperate;

typedef enum : int {
    /// play io task
    EventPlayTaskOperate = 2000, // value is VCPlayTaskOperate
} VCLogEventType;

VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

typedef enum : int {
    VCLogTypeStrategy = 1,
    VCLogTypeError = 2,
} VCLogType;

class VCLogItem : public std::enable_shared_from_this<VCLogItem>, public IVCPrintable {
public:
    typedef std::shared_ptr<VCLogItem> Ptr;

public:
    VCLogItem(VCLogType type, const std::string &module);
    ~VCLogItem() override;

public:
    Ptr put(const std::string &key, const std::string &value);
    Ptr put(const std::string &key, const int value);
    Ptr put(const std::string &key, const float value);
    Ptr put(const std::string &key, const double value);
    Ptr put(const std::string &key, const uint32_t value);
    Ptr put(const std::string &key, const int64_t value);
    Ptr put(const std::string &key, const uint64_t value);
    std::string toString(void) const override;

public:
    int getLogType();

protected:
    VCLogType mLogType;
    std::string mModule;
    uint64_t mTs{0};
    Json::Value mJsonValue;

    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCLogItem);
};

class VCLogStrategyItem : public VCLogItem {
public:
    VCLogStrategyItem(const std::string &module);
    ~VCLogStrategyItem() override;

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCLogStrategyItem);
};

class VCLogErrorItem : public VCLogItem {
public:
    VCLogErrorItem(const std::string &module);
    ~VCLogErrorItem() override;

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCLogErrorItem);
};

class VCLog {
private:
    class _Log {
    public:
        static _Log &imp() {
            static _Log log;
            return log;
        }
        static std::shared_ptr<VCLogItem> obtainStrategyLog(const std::string &module);
        static std::shared_ptr<VCLogItem> obtainErrorLog(const std::string &module);
        void event(const std::shared_ptr<VCLogItem> &logItem);
        void event(const std::string &mediaId, int arg1, int arg2, const std::string &info);

    public:
        void setEventListenerImp(IVCEventListener *eventListener);

    private:
        IVCEventListener *mEventListener{nullptr};
    };

public:
    static const char *PRELOAD;
    static const char *ABR;
    static const char *GLOBAL;

public:
    static std::shared_ptr<VCLogItem> obtainStrategyLog(const std::string &module);
    static std::shared_ptr<VCLogItem> obtainErrorLog(const std::string &module);
    static void eventLog(const std::shared_ptr<VCLogItem> &logItem);
    static void event(const std::string &mediaId, int key, int value, const std::string &info);

public:
    static void setEventListenerImp(IVCEventListener *eventListener);

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCLog);
};

VC_NAMESPACE_END
#endif // PRELOAD_VC_LOG_H
