//  Created by 黄清 on 2020/5/24.
//

#ifndef VCUtilBridge_hpp
#define VCUtilBridge_hpp
#pragma once

#include "vc_base.h"
#include <string>

@class NSString;

VC_NAMESPACE_BEGIN

class VCUtilBridge {
  public:
    static std::string convertToString(const NSString *ocStr);
    static NSString *convertToOCString(const std::string &str);

    static std::shared_ptr<std::vector<std::string>>
    convertToStrArr(NSArray<NSString *> *ocStrArr);
    static NSArray<NSString *> *
    convertToOCStrArr(std::shared_ptr<std::vector<std::string>> strArr);

  private:
    VCUtilBridge() = delete;
    ~VCUtilBridge() = delete;
};

VC_NAMESPACE_END

#endif /* VCUtilBridge_hpp */
