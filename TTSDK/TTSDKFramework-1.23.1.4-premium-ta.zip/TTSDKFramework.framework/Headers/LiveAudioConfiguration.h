
#import <Foundation/Foundation.h>
#import "LiveStreamDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface LiveAudioConfiguration : NSObject

@property (nonatomic, copy) NSDictionary *sdkParams;

@property (nonatomic, assign) NSUInteger audioChannelCount;

@property (nonatomic, assign) NSUInteger audioSampleRate;

@property (nonatomic, assign) BOOL enableAEC;

@property (nonatomic, assign) BOOL enableInEarMonitoring;

@property (nonatomic, assign) BOOL enableNoiseSuppression;
@property (nonatomic, assign) float noiseSuppressionParam;

@property (nonatomic, assign) BOOL enableAudioLoudNorm;
@property (nonatomic, assign) float audioLoudNormParam;

@property (nonatomic, assign) BOOL enableAudioLowLatency;
@property (nonatomic, assign) float audioIOBufferDuration;

@property (nonatomic, assign) BOOL enableClearAudioBuffer;
@property (nonatomic, assign) int clearBufferSize;

@property (nonatomic, assign) BOOL enableFakeThreadNew; 

@property (nonatomic, assign) LSAdmType admType;
@property (nonatomic, copy) NSDictionary *admServerConfig;

@end

NS_ASSUME_NONNULL_END
