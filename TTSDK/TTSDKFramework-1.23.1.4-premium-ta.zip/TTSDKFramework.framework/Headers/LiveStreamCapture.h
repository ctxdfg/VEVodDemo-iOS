
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "LiveStreamDefines.h"
#import "LiveStreamEffectDefines.h"
#import "LSMacros.h"

typedef void(^FetchEffectDetectResultCallback)(int result);

typedef NS_ENUM(NSInteger, LSMovieVideoScaleMode) {
    LSMovieVideoScaleFit        = 0,
    LSMovieVideoScaleAspectFill = 1,
    LSMovieVideoScaleFill       = 2,
};

NS_ASSUME_NONNULL_BEGIN
@class LSLiveAlgorithmResultData;
@class LiveStreamSession;
@class LiveStreamCaptureConfig;
@class LiveStreamRenderSink;
@interface LiveStreamCapture : NSObject

- (instancetype)initWithConfig:(LiveStreamCaptureConfig *)config;

+ (void)resetContext DEPRECATED_MSG_ATTRIBUTE("Use -stopVideoCapture instead");

- (void)startVideoCapture;

- (void)stopVideoCapture;

@property (nonatomic, assign) BOOL renderOnSingleView;

@property (nonatomic, assign) BOOL purgeMemoryIfNeeded;

@property (nonatomic, readwrite) AVCaptureDevicePosition cameraPosition;


@property (nonatomic, assign) NSInteger videoFPS;

@property (nonatomic, assign) OSType inPixelFmt;

@property (nonatomic, assign) LiveStreamRotateMode inRotateMode;

@property (nonatomic, assign) CGSize outputSize;

@property (nonatomic, assign) BOOL mixOnClient;

@property (nonatomic, assign) BOOL movieInteractOnlyPlay;


@property (nonatomic, assign) BOOL karaokeRunning;

- (void)setOutputCropSize:(CGSize)cropSize DEPRECATED_MSG_ATTRIBUTE("use -setCameraCropOutputSize instead");

- (void) setCameraCropOutputSize : (CGSize) cropSize;

- (void) setCameraOutputSize : (CGSize) size;

- (CGSize) getCameraOutputSize;

@property (nonatomic, weak) LiveStreamSession *session;

- (EAGLContext *)getGLContext;

- (LiveStreamCaptureConfig *)getCaptureConfig;

- (NSDictionary <NSString *,NSDictionary*>*)getMixerVideoInfoMessage;

- (void)renderUseSmooth:(BOOL)useSmooth;

- (CVPixelBufferRef)getPixelBufferWithIsEffected:(BOOL)effected;

- (NSData *)getJpegDataWithIsEffected:(BOOL)effected compressionRatio:(CGFloat)ratio;

- (BOOL)isEffectEnabled;

- (void)setEnableEffect:(BOOL)enable;

- (BOOL) isEffectEnabled:(LSLiveEffectType) type;


- (BOOL) isBGMPlaying;

#pragma mark - Preview
- (UIView *)resetPreviewView:(UIView *)view;

- (void)setPreviewFrame:(CGRect)rect;

- (UIView *)previewView;

typedef NS_ENUM(NSInteger, LSPreviewMode) {
    LSPreviewMode_Normal = 0,
    LSPreviewMode_GameInteract,
    LSPreviewMode_Gaming,
    LSPreviewMode_CameraGaming,
    LSPreviewMode_EffectInteractGame,
    LSPreviewMode_MovieInteract,
};
@property (nonatomic, assign) LSPreviewMode previewMode;


- (void)setPreviewMirror:(BOOL)bMirror;

- (void)setStreamMirror:(BOOL)bMirror;

@property (nonatomic, assign, readonly) int cameraLayerId; 
@property (nonatomic, assign) int cameraZOrder; 

@property (nonatomic, assign) BOOL enableKTVCamera;

@property (nonatomic, assign) BOOL enablePipelineKTVCamera;

@property (nonatomic, assign) BOOL needPlayMovieInteractAudio;
@property (nonatomic, copy) void(^firstFrameRenderCallback)(BOOL success, int64_t pts, uint32_t err_no);

#pragma mark - Callback
- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              withCMTime:(CMTime)pts
                toLayer:(GLint)layerId;

- (void)forceDisplayTexture:(int)textureId
                      width:(NSInteger)width
                     height:(NSInteger)height
                        pts:(CMTime)pts
                    layerId:(int)layerId;

- (void)pushVideoTexture:(int)textureId
                   width:(NSInteger)width
                  height:(NSInteger)height
                     pts:(CMTime)pts
                 toLayer:(int)layerId;


- (void)setShouldCheckInputSize:(BOOL)shouldCheck;
- (void)setVideoProcessedCallback:(void (^ _Nullable)(CVPixelBufferRef _Nonnull buffer, GLint texture, CMTime pts))videoProcessedCallback;

#pragma mark - Bypass

- (void)setBypassOutputSize:(CGSize)size pixelFormat:(OSType)fmt enable:(BOOL)enable;

- (void)setBypassOutputSize:(CGSize)size pixelFormat:(OSType)fmt enable:(BOOL)enable isLandscapeVideo:(BOOL)isLandscapeVideo;
- (void)setVideoProcessedBypassCallback:(void (^ _Nonnull)(CVPixelBufferRef _Nonnull buffer, CMTime pts))bypassCallback;

typedef void(^EffectInfoBlock_t)(void *a, void *b);
@property (nonatomic, copy) void(^effectInfoBlck)(void *framebuffer, CMTime frametime, EffectInfoBlock_t(^)(void));

#pragma mark - Effect
- (void)fetchEffectDetectPhotoContentWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType isLastPhone:(BOOL)isLastPhone callback:(FetchEffectDetectResultCallback)callback;

- (void)setEffectRenderCacheTextureWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType;

@property (nonatomic, copy) void(^logCallback)(NSDictionary *log);

@end

@interface LiveStreamCapture (Interact)

- (void)addVideoInput:(CGRect)rect zOrder:(int)zOrder forLayer:(int)layerId;

- (void)addVideoInput:(CGRect)rect
             fillMode:(LSRenderMode)mode
               zOrder:(int)zOrder
             forLayer:(int)layerId
             rotation:(LiveStreamRotateMode)rotate;
- (void)setMixerTriggerLayer:(int)layerId;

- (void)updateVideoRect:(CGRect)rect zOrder:(int)zOrder forLayer:(int)layerId animated:(BOOL)animated frames:(int)frames;
- (void)removeVideoInput:(int)layerId;

- (void)updateSingleViewRect:(CGRect) rect;

- (void)setCanvasColor:(NSString *)colorString;

- (void)pushAudioData:(short *)data size:(NSInteger)size;

- (void)pushFLTAudioData:(float **)data size:(NSInteger) size;

- (void)preparePushExtraAudio:(int) sampleRate channels:(int) channesNumber;

- (void)stopPushExtraAudio;

- (void)setMovieMixVolume:(float) movieVolume captureVolume:(float) captureVolume;

- (void)setMoviePlayVolume:(float) movieVolume;

- (void)startPlayMovie;

- (void)pausePlayMovie:(BOOL)pushLastVideoBuffer;

- (void)stopPlayMovie;

- (void)setMovieMixerMode:(LSMovieVideoScaleMode)mode;

- (void)reportMoviePlayStats;

@end


@interface LiveStreamCapture (ReducedMode)

typedef NS_ENUM(NSInteger, LSCaptureMode) {
    LSCaptureEffectMode,    
    LSCaptureReducedMode    
};

- (instancetype)initWithMode:(LSCaptureMode)mode config:(LiveStreamCaptureConfig *)config;

@end

#pragma LiveStreamCaptureConfig
typedef NS_ENUM(NSInteger, LiveStreamPreviewMode) {
    LiveStreamPreviewMode_LIVE = 0,
    LiveStreamPreviewMode_PK = 1,
    LiveStreamPreviewMode_GAME = 2
};

@interface LiveStreamCaptureConfig : NSObject
#pragma mark - Camera
@property (nonatomic, assign) BOOL useExternalCamera;

#pragma mark - Render or Preview
@property (nonatomic, assign) LiveStreamPreviewMode mode;
@property (nonatomic, assign) BOOL useES3;
@property (nonatomic, copy) NSString *backgroundColorOfCanvas;

#pragma mark - Effect
@property (nonatomic, assign) BOOL useNewEffectLabAPI;
@property (nonatomic, assign) BOOL useAmazing;
@property (nonatomic, copy) NSString *effectPlatformConfig;
@property (nonatomic, copy) NSString *effectLicense; 

+ (LiveStreamCaptureConfig *)defaultConfig;
@end

@interface LiveStreamCapture(DumpRawData)
- (void)startRecordingWithDuration:(NSTimeInterval)duration
                             delay:(NSTimeInterval)delay
                               fps:(NSUInteger)fps
                WithCompletionHandler:(void (^)(NSError * _Nonnull error, int type, NSURL * _Nonnull url))completionHandler;

- (void)resetRecording;
- (BOOL)dumpIsFinished;

- (void) setEffectRecordPath:(NSString *)filePath;


- (void) startRecordingWav:(NSInteger) ticketId maxRecordingDuration:(float) recordingSeconds withCompleteHandler:(void (^)(NSString *audioURL, NSInteger ticketId, NSError *error)) completionHandler;
 
- (void) stopRecordingWav:(void (^)(NSString *audioURL, NSInteger ticketId, NSError *error)) completionHandler;
@end

@interface LiveStreamCapture (statistic)
- (NSDictionary *)getStatisticInfo;
@end

@interface LiveStreamCapture (SpeechRecognizing)
- (void)startSpeechRecognizing;
- (void)stopSpeechRecognizing;
- (BOOL)isSpeechRecognizing;

- (void)setEnableAudioEffect:(BOOL)enable;
@property (nonatomic, copy) void(^speechRecognizeCallback)(NSInteger _id, NSString *info);



@end

@interface LiveStreamCapture (privateAPI)
- (void)audioProcessWithData:(void *_Nonnull)ioData
               processedData:(void *)processedData
              earMonitorData:(void *)earMonitingData
                        size:(UInt32)mDataByteSize
             mNumberChannels:(UInt32)mNumberChannels
              numberOfFrames:(int)inNumberFrames
                     admType:(LSAdmType)admType;
- (void)audioProcessWithData:(void *_Nonnull)ioData
                        size:(UInt32)mDataByteSize
             mNumberChannels:(UInt32)mNumberChannels
              numberOfFrames:(int)inNumberFrames;

- (void)doPlayerProcessWithData:(void *)ioData size:(UInt32)mDataByteSize numberOfFrames:(int)frames;

- (void)p_processOtherMixHandle:(AudioBufferList* )ioData sampleFrames:(NSInteger)inNumberFrames elementIndex:(UInt32)index withMixerHandle:(id )handle;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts needRender:(BOOL)needRender;
@end



NS_ASSUME_NONNULL_END
