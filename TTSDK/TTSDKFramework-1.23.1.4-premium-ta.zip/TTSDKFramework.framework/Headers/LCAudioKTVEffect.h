
#import <Foundation/Foundation.h>

@interface LCAudioKTVEffect : NSObject

- (int)switchKtvEffectWithSourcePath:(NSString *)path;

- (void)processWithData:(short *)data numberOfChannel:(int)channels numberOfSamples:(int)samples;

- (void)startEffect;

- (void)stopEffect;

@end

