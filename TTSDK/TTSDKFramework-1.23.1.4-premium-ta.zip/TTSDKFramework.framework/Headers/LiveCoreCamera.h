/*
  Copyright (c) 2012, Brad Larson, Ben Cochran, Hugues Lismonde, Keitaroh Kobayashi, Alaric Cole, Matthew Clark, Jacob Gundersen, Chris Williams.All rights reserved.

  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

  Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
Neither the name of the GPUImage framework nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <UIKit/UIKit.h>


@protocol LCCameraOutputDelegate <NSObject>

@required

- (void) didCaptureVideoSampleBuffer:(CMSampleBufferRef) videoBuffer;

- (void) didCaptureAudioSampleBuffer:(CMSampleBufferRef) audioBuffer;

@end

@interface LiveCoreCamera : NSObject <AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate>
{
    AVCaptureSession *_captureSession;
    AVCaptureDevice *_inputCamera;
    AVCaptureDevice *_microphone;
    AVCaptureDeviceInput *videoInput;
    AVCaptureVideoDataOutput *videoOutput;
}


@property(readonly, nonatomic) BOOL isRunning;

@property(readonly, retain, nonatomic) AVCaptureSession *captureSession;

@property (readwrite, nonatomic, copy) NSString *captureSessionPreset;

@property (readwrite) int32_t frameRate;

@property (readwrite) OSType outputPixelFmt;

@property (readonly, getter = isFrontFacingCameraPresent) BOOL frontFacingCameraPresent;
@property (readonly, getter = isBackFacingCameraPresent) BOOL backFacingCameraPresent;

@property(readonly) AVCaptureDevice *inputCamera;

@property(readwrite, nonatomic) UIInterfaceOrientation outputImageOrientation;

@property(readwrite, nonatomic) BOOL bMirrorFrontCamera, bMirrorRearCamera;


@property (nonatomic, weak) id<LCCameraOutputDelegate> delegate;

+ (BOOL)isBackFacingCameraPresent;
+ (BOOL)isFrontFacingCameraPresent;

+ (AVCaptureVideoOrientation) uiOrientationToAVOrientation: (UIInterfaceOrientation) orien;


- (id)initWithSessionPreset:(AVCaptureSessionPreset)sessionPreset
             cameraPosition:(AVCaptureDevicePosition)cameraPosition;

- (BOOL)addAudioInputsAndOutputs;

- (BOOL)removeAudioInputsAndOutputs;

- (void)removeInputsAndOutputs;


- (void)startCameraCapture;

- (void)stopCameraCapture;

- (void)pauseCameraCapture;

- (void)resumeCameraCapture;

- (void)startCameraCaptureIfNeeded;

- (AVCaptureDevicePosition)cameraPosition;

- (AVCaptureConnection *)videoCaptureConnection;

- (void)switchCamera;

- (CGSize) captureDimension;

#pragma mark - Torch
- (BOOL) isTorchSupported;

- (void) toggleTorch;

- (void) setTorchMode: (AVCaptureTorchMode)mode;

- (void) setWhiteBalanceMode: (AVCaptureWhiteBalanceMode)mode;
- (void) setExposureMode: (AVCaptureExposureMode)mode;
- (void) setCaptureFocusMode: (AVCaptureFocusMode)mode;

#pragma mark - raw data



@property(nonatomic, assign) NSInteger startErrorCode;

@end
