
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSLinkUserFlags)
{
    LSLinkUserTags_FIT_MODE     = (0x01 << 0),
    LSLinkUserTags_MIRROR_Y     = (0x01 << 1),
    LSLinkUserTags_MIRROR_X     = (0x01 << 2),
};

typedef NS_ENUM(NSUInteger, LSLinkUserVideoMode)
{
    LSLinkUserVideoMode_FIT         = 1,
    LSLinkUserVideoMode_FILL        = 2,
};


@interface LiveStreamLinkInfo : NSObject

@property (nonatomic, copy)      NSString *uid;
@property (nonatomic, assign)    NSInteger fps;
@property (nonatomic, assign)    CGSize outputSize;

#pragma mark - Layout
@property (nonatomic, assign)    double     x;      
@property (nonatomic, assign)    double     y;      
@property (nonatomic, assign)    double     width;  
@property (nonatomic, assign)    double     height; 

@property (nonatomic, assign)    NSInteger  zOrder;
@property (nonatomic, readonly)  int        flags;
@property (nonatomic, assign)    LSLinkUserVideoMode videoMode;
@property (nonatomic, getter=isMirrored) BOOL mirrored;  


@property (nonatomic, assign) CGFloat volume;

@property (nonatomic, assign) int channelsPerFrame;
@property (nonatomic, assign) int bytesPerFrame;
@property (nonatomic, assign) int bitsPerChannel;
@property (nonatomic, assign) int sampleRate;

@end

NS_ASSUME_NONNULL_END
