
#import "LiveCore.h"
#import "LiveCoreCamera.h"
#import "LiveAudioConfiguration.h"
@class LiveStreamCapture;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LCPreviewMode) {
    LCPreviewMode_Normal = 0,
    LCPreviewMode_GameInteract,
    LCPreviewMode_Gaming,
    LCPreviewMode_CameraGaming,
};

typedef NS_ENUM(NSInteger, LiveCoreCaptureMode) {
    LiveCoreCaptureModeAudioAndVideo  = 0, 
    LiveCoreCaptureModeAudioOnly      = 1, 
    LiveCoreCaptureModeVideoOnly      = 2, 
    LiveCoreCaptureModeANDDarkFrame  = 3, 
};


typedef void(^FetchEffectDetectResultCallback)(int result);

@interface LiveCore (Capture)

@property (nonatomic, strong) UIView *previewView;
@property (nonatomic, strong) LiveCoreCamera *camera;
@property (nonatomic, assign) LiveCoreCaptureMode captureMode;

@property (nonatomic, copy) void(^videoProcessingCallback)(CVPixelBufferRef buffer, CMTime pts);

@property (nonatomic, copy) void(^didCapturedVideoFrame)(CVPixelBufferRef buffer, CMTime pts);

#pragma mark - Video
-(void)setLiveCapture:(LiveStreamCapture *)capture;

- (LiveStreamCapture *)liveCapture;

- (void)startVideoCapture;

- (void)startVideoCapture:(AVCaptureSessionPreset)sessionPreset;

- (void)stopVideoCapture;

- (void)resetPreviewOn:(UIView *)view;

- (void)setPreviewMode:(LCPreviewMode)mode;

- (void)setPreviewMirror:(BOOL)bMirror;


- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts;

#pragma mark - Audio main
- (void)setupAudioCaptureWithConfig:(LiveAudioConfiguration *)config;
- (void)startAudioCapture;
- (NSError*)startAudioCaptureWithCert:(id)cert;

- (void)stopAudioCapture;
- (NSError*)stopAudioCaptureWithCert:(id)cert;

- (void)startFakeAudioCapture;

- (void)stopFakeAudioCapture;

- (void)audioCaptureInterrupted:(BOOL)bInterrupt;
- (NSError*)audioCaptureInterrupted:(BOOL)bInterrupt withCert:(id)cert;

- (void)audioPlayerInterrupted:(BOOL)bInterrupt;

#pragma mark - Audio set
- (void)setEnableAudioCaptureInBackground:(BOOL)enable;

- (void)setEnableSpeaker:(BOOL)enable;

- (void)setEnableNoiseSuppression:(BOOL)enable param:(float)param;

- (void)setEnableAudioLoudNorm:(BOOL)enable param:(float)param;

- (void)setHeadphonesMonitoringEnabled:(BOOL)headphonesMonitoringEnabled;

- (void)setEchoCancellationEnabled:(BOOL)echoCancellationEnabled;
- (NSError*)setEchoCancellationEnabled:(BOOL)enable withCert:(id)cert;

- (void)setEnablePlayer:(BOOL)enable;

- (void)setEnableAutoResumeAudioCaptureOnAppActive:(BOOL) autoResumeCapture;
- (void)setAutoResumeVideoCaptureOnAppActive:(BOOL)autoResume;

- (void)setEnableAudioLowLatency:(BOOL)enable ioBufferDuration:(float)ioBufferDuration;

- (void)setEnablePlayoutEcho:(BOOL)enable;

#pragma mark - Audio get
- (BOOL)isMicRunning;

- (BOOL)isFakeAudioCaptureRunning;

- (BOOL)isHeadphonesMonitoringEnabled;

- (BOOL)isEchoCancellationEnabled;

- (BOOL)isRouteToSpeaker;
- (AudioStreamBasicDescription)audioStreamBasicDescription;

- (NSDictionary *)getAudioQosInfo;

- (int64_t)getLatestAudioPts;

#pragma mark - Recognize
- (void)startSpeechRecognizing;
- (void)stopSpeechRecognizing;
- (BOOL)isSpeechRecognizing;

- (CVPixelBufferRef)getPixelBufferWithIsEffected:(BOOL)effected;

- (NSData *)getJpegDataWithIsEffected:(BOOL)effected compressionRatio:(CGFloat)ratio;

#pragma mark - Effect AB Info Set and Get

- (void)setEffectABLicense:(NSString *_Nonnull)license;

- (void)setEffectABInfo:(NSString *)abInfo;

+ (void)setEffectABInfo:(NSString *)abInfo withLicense:(NSString *)license;

+ (NSString *)getEffectABInfoWithLicense:(NSString *)license;

- (void)fetchEffectDetectPhotoContentWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType isLastPhone:(BOOL)isLastPhone callback:(FetchEffectDetectResultCallback)callback;

- (void)setEffectRenderCacheTextureWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType;

@end

NS_ASSUME_NONNULL_END
