
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@class LSLiveAudioReverbFormat;
@class LSLiveAudioEqualizerFormat;
@class LSLiveAudioReverb2Format;
@class LSLiveAudioCleanerFormat;
@class LSLiveAudioExciterFormat;
@class LSLiveAudioCompressorFormat;

@interface LSLiveAudioEffect : NSObject

- (instancetype)initWithSampleRate:(Float64)sampleRate
                          channels:(int)channels
                          useFloat:(BOOL)useFloat;


- (void)processSingScoreBuffer:(AudioBuffer)buffer samplePerCh:(int)samplePerCh;

- (void)processBuffer:(AudioBuffer)buffer samplePerCh:(int)samplePerCh;

- (void)processBufferList:(AudioBufferList *)ioData;

- (BOOL)needProcess;

#pragma mark - StereoWiden
- (void)updateStereoWiden:(int)weightId;

#pragma mark - reverb params
- (void)updateReverbFormat:(LSLiveAudioReverbFormat *)format;

#pragma mark - equalizer params
- (void)updateEqualizerFormat:(LSLiveAudioEqualizerFormat *)format;

#pragma mark - reverb2 params
- (void)updateReverb2Format:(LSLiveAudioReverb2Format *)format;

#pragma mark - audio cleaner params
- (void)updateAudioCleanerFormat:(LSLiveAudioCleanerFormat *)format;

- (void)updateExciterFormat:(LSLiveAudioExciterFormat *)format;

- (void)updateCompressFormat:(LSLiveAudioCompressorFormat *)format;

- (void)enableCleaner:(BOOL)enableCleaner;

- (void)enableExciter:(BOOL)enableExciter;

- (void)enableCompressor:(BOOL)enableCompressor;

@end
