#pragma once

#ifdef WIN32
#define BYTEAUDIO_API __declspec(dllexport)
#else
#define BYTEAUDIO_API __attribute__((__visibility__("default")))
#endif

#include <stdint.h>

#include <string>
#include <vector>

namespace bae {

struct ByteAudioEngineInputReport {
    //
    // audio record device report
    //
    std::string audio_layer = "";
    uint32_t record_sample_rate = 0;
    uint32_t record_channels = 0;
    double record_level_full_range = 0.0;
    double record_level = 0.0;
    double record_total_energy = 0.0;
    double record_total_duration = 0.0;
    int mic_volume = -1;
    bool mic_mute = false;
    int32_t record_smooth_audio_level = 0;
    // current device mode. Android: AudioManager mode; iOS:AVAudioSesssion mode; Win: whether is DMO; Mac: null
    std::string audio_device_mode = "";
    // record frame rate (per second)
    double record_frame_rate = 0.0;
    // record gain
    float record_volume = 0.f;
    // whether record device is on
    bool is_record_started = false;

    //
    // audio pre-process report
    //
    bool prep_aec_enable = false;
    uint32_t prep_aec_mode = 2;
    uint32_t prep_aec_level = 0;

    bool prep_ans_enable = false;
    uint32_t prep_ans_mode = 2;
    uint32_t prep_ans_level = 0;
    float prep_denoise_db = 0;

    bool prep_agc_enable = false;
    uint32_t prep_agc_mode = 0;
    float prep_agc_gain_db = 0;

    bool prep_vad_enable = false;
    uint32_t prep_vad_mode = 0;
    uint32_t prep_vad_proc_count = 0;

    bool loudnorm_enable = false;

    double prep_echo_return_loss = 0.0;
    double prep_echo_return_loss_enhancement = 0.0;
    int32_t prep_echo_delay_ms = 0;
    int32_t prep_echo_delay_median_ms = 0;
    int32_t prep_echo_delay_standard_deviation_ms = 0;
    float prep_residual_echo_likelihood = 0;
    float prep_residual_echo_likelihood_max = 0;
    double prep_nonlinear_process_suppression = 0.0;

    double prep_front_filter_rtf = 0.0;
    double prep_aec_rtf = 0.0;
    double prep_ans_rtf = 0.0;
    double prep_agc_rtf = 0.0;
    double vocal_loudnorm_rtf = 0.0;
    double prep_back_filter_rtf = 0.0;

    int prep_front_filter_input_level = 0;
    int prep_front_filter_output_level = 0;
    int prep_aec_input_level = 0;
    int prep_aec_output_level = 0;
    int prep_ans_output_level = 0;
    int prep_agc_output_level = 0;
    int vocal_loudnorm_input_level = 0;
    int vocal_loudnorm_output_level = 0;
    int prep_back_filter_input_level = 0;
    int prep_back_filter_output_level = 0;
    
    // lark merge
    uint32_t prep_aagc_volume = 0;
    uint32_t prep_rnnoise_level = 0;
    bool prep_mic_aagc_enable = false;
    bool prep_mic_dagc_enable = false;  // merge with prep_agc_enable
    bool prep_mic_fixGain_enable = false;
    bool prep_mic_ns_enable = false;  // merge with prep_ans_enable
    uint32_t prep_mic_ns_gradde = false;
    bool prep_mic_rnnoise_enable = false;
    bool prep_mic_ainoise_enable = false;
    uint32_t prep_mic_aec_type = 0;
    int32_t prep_declipper_count = 0;
    int32_t prep_declipper_time = 0;
    bool prep_echo_check_enable = false;
    bool prep_mic_anr_enable = false;
    bool prep_mic_aec_ainr_enable = false;
    bool pitch_vad = false;
    int32_t mic_ns_grade = 0;
    int32_t prep_playback_level = 0;
    double prep_total_energy = 0.0;
    double prep_total_duration = 0.0;
    double prep_smooth_audio_level = 0.0;

    int prep_channel_select = -1;
    
    //
    // screen input device report
    //
    double sceen_input_volume = 0.0;
    double sceen_input_level_full_range = 0.0;
    double sceen_input_level = 0.0;
    double sceen_input_total_energy = 0.0;
    double sceen_input_total_duration = 0.0;
    bool is_screen_started = false;
    double screen_frame_rate = 0.0;
};

struct ByteAudioEngineOutputReport {
    //
    // audio output device report
    //
    std::string audio_layer = "";
    uint32_t play_sample_rate = 0;
    uint32_t play_channels = 0;
    float playback_volume = 0.0;
    double play_level_full_range = 0.0;
    double play_level = 0.0;
    double play_total_energy = 0.0;
    double play_total_duration = 0.0;
    int speaker_sys_volume = -1;
    int speaker_app_volume = -1;
    bool speaker_mute = false;
    // whether play device is on
    bool is_play_started = false;
    // whether play device is system default device
    bool is_system_default_play_device = true;
    // playback frame rate (per second)
    double play_frame_rate = 0.0;
    
    //
    // audio post-process report
    //
    bool post_enable_eq = false;
    bool post_enable_drc = false;
    uint32_t post_sample_rate = 0;
    uint32_t post_channel_num = 0;
    int post_play_gain = 100;
    
    double post_filter_rtf = 0.0;
    int post_filter_input_level = 0;
    int post_filter_output_level = 0;
    
    int headset_monitor_volume = 0;
};

struct ByteAudioInputStreamReport {
    // uint32_t down_stream_num = 0;
    
    // stream info
    std::string stream_name = "";
    uint32_t stream_id = 0;
    std::string stream_addr = "";
    int stream_state = 0;
    bool impact_device = true;
    
    // input sink statistic
    std::string input_sink_addr = "";
    double input_sink_rtf = 0.0;
    double input_sink_frame_rate = 0.0;
    
    // audio mix node statistic
    uint32_t mix_source = 0;
    uint32_t mix_out_sample_rate = 0;
    uint32_t mix_out_channels = 0;
    int mix_out_level = 0;
    
    // audio encode layer statistic
    bool enc_input_mute = false;
    int enc_input_gain = 0;
    double enc_input_audio_level_full_range = 0.0;
    double enc_input_audio_level = 0;
    double enc_input_duration = 0;
    double enc_input_energy = 0.0;

    uint32_t enc_input_sample_rate = 0;
    uint32_t enc_input_channel_num = 0;

    std::string enc_codec_type = "";
    uint32_t enc_sample_rate = 0;
    uint32_t enc_channel_num = 0;
    uint32_t enc_frame_length;
    uint32_t enc_target_bitrate = 0;
    uint32_t enc_dtx_count = 0;
    uint32_t enc_bitrate = 0;
    
    double enc_rtf = 0.0;
    double enc_inband_fec_rate = 0.0;
    int enc_inband_fec_lossrate = 0;
};

struct ByteAudioOutputStreamReport {
    // stream info
    std::string stream_name = "";
    uint32_t stream_id = 0;
    std::string stream_addr = "";
    int stream_state = 0;

    // output sink statistic
    std::string output_sink_addr = "";
    double output_sink_rtf = 0.0;
    double output_sink_frame_rate = 0.0;
    
    // audio decode statistic
    uint32_t dec_muted = 0;
    bool dec_output_mute = false;
    double dec_output_gain = 0.0;
    double recv_audio_level_full_range = 0.0;
    double recv_audio_level = 0;
    double recv_audio_total_energy = 0.0f;
    double recv_audio_total_duration = 0.0f;
    int32_t recv_smooth_audio_level = 0.0f;
    
    std::string dec_codec_type = "";
    uint32_t dec_sample_rate = 0;
    uint32_t dec_channels = 0;
    uint32_t dec_frame_length = 0;
    double dec_duration = 0;
    uint32_t dec_samples_out = 0;
    
    float current_packet_loss_rate = 0.0f;

    float accelerate_rate = 0.0f;
    float preemptive_expand_rate = 0.0f;
    float expand_rate = 0.0f;
    float speech_expand_rate = 0.0f;

    uint64_t lated_packet_samples = 0;
    int32_t decoding_normal_count = 0;
    int32_t decoding_plc_count = 0;
    int32_t decoding_cng_count = 0;
    int32_t decoding_plc_cng_count = 0;
    int32_t decoding_inbandfec_count = 0;

    uint64_t concealed_samples = 0;
    uint64_t concealment_event = 0;
    uint64_t accelerate_samples = 0;
    uint64_t preemptive_samples = 0;
    // uint64_t recv_total_samples = 0;
    uint32_t dec_dtx_count = 0;

    uint64_t stall_count_vc = 0;
    uint64_t stall_time_ms_vc = 0;
    uint64_t active_time_ms_vc = 0;
    uint64_t dtx_time_ms_vc = 0;
    
    double decoding_rtf = 0.0;
    
    uint32_t nico_dec_1stream_cnt = 0;
    uint32_t nico_dec_2stream_cnt = 0;
};

struct ByteAudioAuxStreamReport {
    // stream info
    std::string stream_name = "";
    uint32_t stream_id = 0;
    std::string stream_addr = "";
    int stream_status = -1;
    int stream_type = -1;
    
    // mixing stats
    bool stream_muted = false;
    int stream_gain = 0;
    bool mix_to_input = false;
    int mix_to_input_gain = 0;
    bool mix_to_output = false;
    int mix_to_output_gain = 0;
    
    double publish_level = 0.0;
    double publish_total_energy = 0.0;
    double publish_total_duration = 0.0;
    double playout_level = 0.0;
    double playout_total_energy = 0.0;
    double playout_total_duration = 0.0;
    
    // loudnorm stats
    float integrated_loudness = 1.0f;
    
    // compensate delay for publish to playout
    int publish_to_playout_delay_ms = 0;
    
    // file mode
    int file_position = 0;
    int file_duration = 0;
    int file_loop_count = 0;
    int file_audio_track = 0;
    
    // pcm pull mode
    std::string aux_sink_addr = "";
    double aux_sink_rtf = 0.0;
    double aux_sink_frame_rate = 0.0;
    
    // pcm push mode
    uint32_t publish_drop_count = 0;
    uint32_t playout_drop_count = 0;
};

// deprecated
struct ByteAudioEngineReport {
    //range [0, 1]
    double record_level = 0.0;
    //range [0, 1]
    double playout_level = 0.0;
};

}  // namespace bae
