//
//  TTVideoEngine+Strategy.h
//  TTVideoEngine
//
//  Created by wangzhiyong on 2021/11/15.
//

#import "TTVideoEngine.h"
#import "TTVideoEngineMediaSource.h"

NS_ASSUME_NONNULL_BEGIN

@class TTVideoEngineVidSource;
@class TTVideoEngineUrlSource;
@class TTVideoEngineMultiEncodingUrlSource;

/// Strategy Type
typedef NS_ENUM(NSInteger, TTVideoEngineStrategyType) {
    TTVideoEngineStrategyTypeNone      = 1 << 0,
    TTVideoEngineStrategyTypeCommon    = 1 << 1,
    TTVideoEngineStrategyTypePreload   = 1 << 2,
    TTVideoEngineStrategyTypePreRender = 1 << 3,
};
/// Strategy scene
FOUNDATION_EXTERN NSString * TTVEngineStrategySceneSmallVideo;

@interface TTVideoEngine (EngineStrategyPlay)

/// Set play source, use mdl to load data.
/// @param source vid-TTVideoEngineVidSource, url-TTVideoEngineUrlSource, codecUrl-TTVideoEngineMultiEncodingUrlSource
- (void)setVideoEngineVideoSource:(id<TTVideoEngineMediaSource>)source;

/// Set play source, use mdl to load data.
/// @param source vid-TTVideoEngineVidSource, url-TTVideoEngineUrlSource, codecUrl-TTVideoEngineMultiEncodingUrlSource
/// @param codecStrategy TTVideoEngineCodecStrategy
- (void)setVideoEngineVideoSource:(id<TTVideoEngineMediaSource>)source codecStrategy:(TTVideoEngineCodecStrategy)codecStrategy;

@end

@interface TTVideoEngine (EngineStrategy)

/// Enable engine strategy, open ViewController settings enable strategy, do not repeat settings
/// @param strategyType  support (TTVideoEngineStrategyTypeCommon | TTVideoEngineStrategyTypePreload | TTVideoEngineStrategyTypePreRender)
/// @param scene use TTVEngineStrategySceneSmallVideo
+ (BOOL)enableEngineStrategy:(TTVideoEngineStrategyType)strategyType scene:(NSString *)scene;

/// Clearn all engine strategy,
/// Make sure close ViewController clear old engine strategy
+ (void)clearAllEngineStrategy;

@end

@interface TTVideoEngine (EngineStrategySource)

// When enable (TTVideoEngineStrategyTypePreload|TTVideoEngineStrategyTypePreRender) strategy
// Need to set the current playlist

/// Set up playlist, E.g Refresh data
/// @param videoSources play sources
+ (void)setStrategyVideoSources:(NSArray<id<TTVideoEngineMediaSource>> *)videoSources;
/// Add playlist to current playlist, E.g Load more data
/// @param videoSources play sources
+ (void)addStrategyVideoSources:(NSArray<id<TTVideoEngineMediaSource>> *)videoSources;

/// Set up playlist, E.g Refresh data
/// Support codec strategy,
/// @param videoSources play sources
/// @param codecStrategy TTVideoEngineCodecStrategy
+ (void)setStrategyVideoSources:(NSArray<id<TTVideoEngineMediaSource>> *)videoSources codecStrategy:(TTVideoEngineCodecStrategy)codecStrategy;
/// Add playlist to current playlist, E.g Load more data
/// Support codec strategy,
/// @param videoSources play sources
/// @param codecStrategy TTVideoEngineCodecStrategy
+ (void)addStrategyVideoSources:(NSArray<id<TTVideoEngineMediaSource>> *)videoSources codecStrategy:(TTVideoEngineCodecStrategy)codecStrategy;

@end


@protocol TTVideoEnginePreRenderDelegate <NSObject>

/**
 This will be called before video engine prepare to play

@param videoEngine videoengine
*/
- (void)videoEngineWillPrepare:(TTVideoEngine *)videoEngine;

@end

@interface TTVideoEngine (EngineStrategyPreRender)

/// Set pre render VideoEngineDelegate
/// @param delegate video engine delegate
+ (void)setPreRenderVideoEngineDelegate:(id<TTVideoEnginePreRenderDelegate>)delegate;

/// Get pre render videoEngine, use this videoEngine replace current play videoEngine
/// If return nil, use the original logic
/// @param source vid-TTVideoEngineVidSource, url-TTVideoEngineUrlSource, codecUrl-TTVideoEngineMultiEncodingUrlSource
+ (TTVideoEngine * _Nullable)getPreRenderVideoEngineWithVideoSource:(id<TTVideoEngineMediaSource>)source;

/// Get pre render player view, player view can be use backgroud image
/// If return nil, use the original logic
/// @param source vid-TTVideoEngineVidSource, url-TTVideoEngineUrlSource, codecUrl-TTVideoEngineMultiEncodingUrlSource
+ (UIView * _Nullable)getPreRenderFinishedPlayerViewWithVideoSource:(id<TTVideoEngineMediaSource>)source;
/// Get pre render player view, player view can be use backgroud image
+ (TTVideoEngine * _Nullable)getPreRenderFinishedVideoEngineWithVideoSource:(id<TTVideoEngineMediaSource>)source;

@end

NS_ASSUME_NONNULL_END
