
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LCAudioScoreMidiDrawingData : NSObject

@property(nonatomic, assign) int pitch;
@property(nonatomic, assign) int32_t start;
@property(nonatomic, assign) int32_t duration;

@end

@interface LCAudioScoreRealtimeInfo : NSObject

@property(nonatomic, assign) double sentenceScore;   
@property(nonatomic, assign) double songScore;       
@property(nonatomic, assign) double userPitch;       
@property(nonatomic, assign) int userNote;           
@property(nonatomic, assign) int userCent;           
@property(nonatomic, assign) int userOctave;         
@property(nonatomic, assign) double userFrequency;   
@property(nonatomic, assign) double refPitch;        
@property(nonatomic, assign) int refNote;            
@property(nonatomic, assign) int refCent;            
@property(nonatomic, assign) double refFrequency;    
@property(nonatomic, assign) int sentenceIndex;      
@property(nonatomic, assign) double actualSentenceScore; 

@end

@interface LCAudioScore : NSObject

- (instancetype)initWithMidiFileName:(const char *)midiFileName lyricFileName:(const char *)lyricFileName;

- (instancetype)initWithMidiFileName:(const char *)midiFileName lyricTimeInfo:(const int32_t*)lyricTimeInfo;

- (void)startScore;

- (void)stopScore;

- (NSArray<LCAudioScoreMidiDrawingData*> *)getMidiDrawingData;

- (void)setTranspose:(int)transpose;

- (void)setSongScore:(double)score;

- (void)seek:(double)newPosInSec;

- (LCAudioScoreRealtimeInfo *)getRealtimeInfo;

@end

NS_ASSUME_NONNULL_END
