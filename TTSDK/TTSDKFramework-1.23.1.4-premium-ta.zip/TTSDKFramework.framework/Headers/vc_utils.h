//  Created by 黄清 on 2020/5/22.
//

#ifndef Utils_hpp
#define Utils_hpp
#pragma once

#include "vc_base.h"
#include <stdio.h>
#include <string>
#include <vector>

VC_NAMESPACE_BEGIN

class VCMethodConsume {
public:
    explicit VCMethodConsume(const std::string &des);
    ~VCMethodConsume();

private:
    static uint64_t Serial_num;

private:
    std::string mDes;
    uint64_t mMSTime{0};
    uint64_t mSerialNum{0};

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMethodConsume);
};

#ifndef __METHOD_CONSUME__
#define __METHOD_CONSUME__

#define DEBUG_TIMING 0
#if DEBUG || DEBUG_TIMING
#define METHOD_CONSUME(des) __attribute__((__unused__)) VCMethodConsume unUseInstace(des)
#else
#define METHOD_CONSUME(des)
#endif
#endif

VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

class Utils {

public:
    static std::vector<std::string> split(const std::string &str, const std::string &delim);
    static std::int64_t getCurrentTimestamp(void);

public:
#if defined(__ANDROID__)
    static bool attachEnv(void);
    static void detachEnv(void);
#endif

public:
    static std::string BuildPlayerID(const std::string &sceneId, const std::string &mediaId);
};

VC_NAMESPACE_END

#endif /* Utils_hpp */
