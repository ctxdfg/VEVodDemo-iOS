//
//  BDDownloadChromiumTask.h
//  BDWebImage
//
//  Created by 刘诗彬 on 2017/12/4.
//

#import "BDDownloadTask.h"

@interface BDDownloadChromiumTask : BDDownloadTask

@end
