//
// Created by zhongzhendong on 2020/12/2.
//

#ifndef STRATEGYCENTER_UNIQUE_OBJECT_H
#define STRATEGYCENTER_UNIQUE_OBJECT_H

#include "vc_base.h"

VC_NAMESPACE_BEGIN

template <typename T, typename Traits> class UniqueObject {
private:
    // This must be first since it's used inline below.
    //
    // Use the empty base class optimization to allow us to have a Traits
    // member, while avoiding any space overhead for it when Traits is an
    // empty class.  See e.g. http://www.cantrip.org/emptyopt.html for a good
    // discussion of this technique.
    struct Data : public Traits {
        explicit Data(const T &in): value(in) {}
        Data(const T &in, const Traits &other): Traits(other), value(in) {}

        T value;
    };

public:
    using element_type = T;
    using traits_type = Traits;

    UniqueObject(): data_(Traits::InvalidValue()) {}
    explicit UniqueObject(const T &value): data_(value) {}

    UniqueObject(const T &value, const Traits &traits): data_(value, traits) {}

    UniqueObject(UniqueObject &&other): data_(other.release(), other.get_traits()) {}

    ~UniqueObject() { FreeIfNecessary(); }

    UniqueObject &operator=(UniqueObject &&other) {
        reset(other.release());
        return *this;
    }

    void reset(const T &value = Traits::InvalidValue()) {
        assert(data_.value == Traits::InvalidValue() || data_.value != value);
        FreeIfNecessary();
        data_.value = value;
    }

    void swap(UniqueObject &other) {
        // Standard swap idiom: 'using std::swap' ensures that std::swap is
        // present in the overload set, but we call swap unqualified so that
        // any more-specific overloads can be used, if available.
        using std::swap;
        swap(static_cast<Traits &>(data_), static_cast<Traits &>(other.data_));
        swap(data_.value, other.data_.value);
    }

    // Release the object. The return value is the current object held by this
    // object. After this operation, this object will hold an invalid value, and
    // will not own the object any more.
    [[nodiscard]] T release() {
        T old_value = data_.value;
        data_.value = Traits::InvalidValue();
        return old_value;
    }

    const T &get() const { return data_.value; }

    bool is_valid() const { return Traits::IsValid(data_.value); }

    bool operator==(const T &value) const { return data_.value == value; }

    bool operator!=(const T &value) const { return data_.value != value; }

    Traits &get_traits() { return data_; }
    const Traits &get_traits() const { return data_; }

private:
    void FreeIfNecessary() {
        if (data_.value != Traits::InvalidValue()) {
            data_.Free(data_.value);
            data_.value = Traits::InvalidValue();
        }
    }

    // Forbid comparison. If U != T, it totally doesn't make sense, and if U ==
    // T, it still doesn't make sense because you should never have the same
    // object owned by two different UniqueObject.
    template <typename T2, typename Traits2>
    bool operator==(const UniqueObject<T2, Traits2> &p2) const = delete;

    template <typename T2, typename Traits2>
    bool operator!=(const UniqueObject<T2, Traits2> &p2) const = delete;

    Data data_;

    VC_DISALLOW_COPY_AND_ASSIGN(UniqueObject);
};

template <class T, class Traits>
void swap(const UniqueObject<T, Traits> &a, const UniqueObject<T, Traits> &b) {
    a.swap(b);
}

template <class T, class Traits>
bool operator==(const T &value, const UniqueObject<T, Traits> &object) {
    return value == object.get();
}

template <class T, class Traits>
bool operator!=(const T &value, const UniqueObject<T, Traits> &object) {
    return !(value == object.get());
}

VC_NAMESPACE_END

#endif // STRATEGYCENTER_UNIQUE_OBJECT_H
