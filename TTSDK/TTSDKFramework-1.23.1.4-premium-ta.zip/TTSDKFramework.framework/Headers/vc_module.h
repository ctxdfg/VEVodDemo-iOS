//
// Created by 黄清 on 4/22/21.
//

#ifndef PRELOAD_VC_MODULE_H
#define PRELOAD_VC_MODULE_H
#pragma once

#include "vc_base.h"
#include "vc_imodule.h"

VC_NAMESPACE_BEGIN

///
/// Api of all strategy modules
///
class VCMediaInfo;
class VCCoordinator;
class VCModuleConfig;
class VCModule final : public IVCModule {
public:
    VCModule();
    ~VCModule() override;

public:
    bool addModule(IVCModule *module);
    /// type is single value.
    IVCModule *getModule(VCModuleType type);

    void start() override;
    void stop() override;
    void stop(bool isAppTerminate);

    void receiveMessage(std::shared_ptr<VCMessage> &message) override;

public:
    void setContext(IVCContext *ctx);
    void setListener(IVCResultListener *lst);
    void setConfig(VCModuleConfig *cng);

public: /// All modules functions.
    /// invalid value. -1
    float getNetworkSpeedKBPS(void);
    /// invalid value. -1
    int getSelectBitrate(std::shared_ptr<VCMediaInfo> &mediaInfo, SelectBitrateType selectType);

    void netSample(uint32_t sizeB, uint32_t timeMS, std::string &trackType);

private:
    std::list<IVCModule *> mModules;
    VCCoordinator *mCoordinator{nullptr};
    VCModuleConfig *mConfig{nullptr};
};

VC_NAMESPACE_END

#endif // PRELOAD_VC_MODULE_H
