//
//  BDWebImageURLFilter.h
//  BDWebImage
//
//

#import <Foundation/Foundation.h>

@interface BDWebImageURLFilter : NSObject

- (NSString *)identifierWithURL:(NSURL *)url;

@end
