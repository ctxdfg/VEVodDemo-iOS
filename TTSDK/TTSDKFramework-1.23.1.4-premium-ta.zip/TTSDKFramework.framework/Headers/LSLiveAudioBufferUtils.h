
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef struct AudioBufferQueue {
    UInt8    *bufferData;
    UInt32   dataSize;
}AudioBufferQueue;

@interface LSLiveAudioBufferUtils : NSObject

+ (AudioBufferList *)createBufferList:(AudioStreamBasicDescription)audioFormat frameCount:(UInt32)frameCount;
+ (void)freeBufferList:(AudioBufferList*)bufferList;
+ (void)copyBufferList:(AudioBufferList *)dstBufferList srcBufferList:(AudioBufferList *)srcBufferList;

+ (void)copyBufferList:(void *)dstBufferList srcBufferList:(void *)srcBufferList size:(UInt32)size channels:(UInt32)channels;

+ (void)createBufferQueue:(AudioBufferQueue *)bufferQueue;

+ (void)freeBufferQueue:(AudioBufferQueue *)bufferQueue;

+ (void)resetBufferQueue:(AudioBufferQueue *)bufferQueue;

+ (void)pushQueue:(AudioBufferQueue *)bufferQueue srcData:(int16_t *)srcData dataSize:(UInt32)dataSize;

+ (int)dequeue:(AudioBufferQueue *)bufferQueue dstData:(int16_t *)dstData outputSize:(UInt32)outputSize;

+ (void)resetAudioBufferList:(AudioBufferList *)bufferList;

+ (void)mixAudioBufferList:(AudioBufferList *)srcBufferList dstBufferList:(AudioBufferList *)dstBufferList;


+ (void)mixAudioDataWithVolume:(short *)srcData
                     srcLength:(int)srcLength
                           srcVolume:(CGFloat)srcVolume
                       dstData:(short *)dstData
                     dstLength:(int)dstLength
                     dstVolume:(CGFloat)dstVolume;

+ (void)mixAudioBufferListWithVolume:(AudioBufferList *)srcBufferList
                           srcVolume:(CGFloat)srcVolume
                       dstBufferList:(AudioBufferList *)dstBufferList
                           dstVolume:(CGFloat)dstVolume;

+ (void)mixAudioBuffer:(int16_t *)srcData
           srcDataSize:(UInt32)srcDataSize
             srcVolume:(CGFloat)srcVolume
             dstBuffer:(int16_t *)dstData
           dstDataSize:(UInt32)dstDataSize
             dstVolume:(CGFloat)dstVolume;

+ (void)writePCMFile:(NSString *)fileName pcmData:(Byte *)pcmData length:(int)length;

@end

NS_ASSUME_NONNULL_END
