//
// Created by 黄清 on 4/20/21.
//

#ifndef PRELOAD_VC_CONTEXT_H
#define PRELOAD_VC_CONTEXT_H
#pragma once

#include "vc_base.h"
#include "vc_scene_config.h"
#include <list>
#include <stdio.h>
#include <string>

VC_NAMESPACE_BEGIN

typedef enum : int {
    VCModuleTypeUnknown = 0,
    VCModuleTypePreload = 1 << 0, /// 1
    VCModuleTypeABR = 1 << 1,     /// 2
    VCModuleTypeSelectBitrate = 1 << 2,
    VCModuleTypeBandwidth = 1 << 3,
    VCModuleTypeLoadControl = 1 << 4,
    VCModuleTypePlayRange = 1 << 5, /// 32
} VCModuleType;

static inline bool singleModuleType(VCModuleType type) {
    bool ret = false;
    switch (type) {
    case VCModuleTypeUnknown:
    case VCModuleTypePreload:
    case VCModuleTypeABR:
    case VCModuleTypeSelectBitrate:
    case VCModuleTypeBandwidth:
    case VCModuleTypeLoadControl:
    case VCModuleTypePlayRange:
        ret = true;
        break;
    default:
        break;
    }
    return ret;
}

static inline VCModuleType operator|(VCModuleType lhs, VCModuleType rhs) {
    return static_cast<VCModuleType>(static_cast<int>(lhs) | static_cast<int>(rhs));
}

static inline VCModuleType operator&(VCModuleType lhs, VCModuleType rhs) {
    return static_cast<VCModuleType>(static_cast<int>(lhs) & static_cast<int>(rhs));
}
VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

class VCMediaInfo;
class VCSegment;
class VCMessage;
class IVCContext {
public:
    virtual int getNetworkType() = 0;
    virtual int64_t getNetSpeed() = 0;
    /// Player
    virtual int64_t getMaxCacheSize() = 0;
    virtual int64_t getCurrentPlayerMinStartBuffer() = 0;
    virtual int getCurrentPlaybackState() = 0;
    virtual int getCurrentPlaybackPosition() = 0;
    virtual float getCurrentPlaybackSpeed() = 0;
    virtual int64_t getCurrentPlayAudioBufferMS() = 0;
    virtual int64_t getCurrentPlayVideoBufferMS() = 0;
    virtual int64_t getCurrentPlayAudioBufferSize() = 0;
    virtual int64_t getCurrentPlayVideoBufferSize() = 0;
    /// media duration, is millisecond.
    virtual int getCurrentPlayDuration() = 0;
    virtual std::vector<std::shared_ptr<VCSegment>> getCurrentPendingSegment() = 0;
    virtual int getIntValAtPlayer(const std::string &mediaId, int key, int dVal) = 0;

    virtual std::string getCurrentSceneId() = 0;
    virtual std::shared_ptr<VCMediaInfo> getMediaById(const std::string &mediaId) = 0;
    virtual std::shared_ptr<VCMediaInfo> getCurrentPlayMedia() = 0;
    virtual std::list<std::shared_ptr<VCMediaInfo>> getMediaList(const std::string &sceneId) = 0;
    virtual MediaInfoVector getNextMedias(const std::string &mediaId, int count) = 0;

    virtual int64_t getFileCacheSizeByKey(const std::string &fileKey) = 0;
    virtual int64_t getFileSizeByKey(const std::string &fileKey) = 0;

    virtual RepresentationMap
    getPredictSelectRepresentations(const std::shared_ptr<VCMediaInfo> &media) = 0;

    virtual RepresentationMap
    getPredictSelectRepresentations(const std::shared_ptr<VCMediaInfo> &media,
                                    const std::string sceneId) = 0;

    virtual bool currentPlayIsIdle(void) = 0;
    /// key is VCKeyConfigAlgoXXX
    virtual std::string getConfigString(VCKey configKey) = 0;

public: /// operate
    virtual void sendMessage(const std::shared_ptr<VCMessage> &msg) = 0;

public:
    virtual ~IVCContext(){};
};

VC_NAMESPACE_END
#endif // PRELOAD_VC_CONTEXT_H
