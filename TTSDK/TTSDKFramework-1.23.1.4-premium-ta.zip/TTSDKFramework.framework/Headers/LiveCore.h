//  Copyright © 2019 live-sdk. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import "LiveStreamLibrary.h"

typedef NS_ENUM(NSInteger,LiveCoreRunState)
{
    LiveCoreRunStateNone = 0,
    LiveCoreRunStateStartStreaming ,
    LiveCoreRunStateStopStreaming,
    LiveCoreRunStateWillStartInteractStreaming,
    LiveCoreRunStateStartInteractStreaming ,
    LiveCoreRunStateStopInteractStreaming,
    LiveCoreRunStateEndLiveCore,
};
typedef NS_ENUM(NSUInteger, LiveCoreNetworkQuality) {
    LiveCoreNetworkQualityUnknown = 0,
    LiveCoreNetworkQualityExcellent,
    LiveCoreNetworkQualityPoor,
    LiveCoreNetworkQualityBad,
};


typedef NS_ENUM(NSInteger, LiveCoreAudioPlayerMode)
{
    eLiveCoreAudioPlayerOnlyPlay = 0,   
    eLiveCoreAudioPlayerOnlyCDN = 1,    
    eLiveCoreAudioPlayerCDNAndRTC = 2,  
};


@class LiveStreamSession;
@class LiveStreamConfiguration;

#pragma mark - LiveCoreRunInfo

@interface LiveCoreRunInfo : NSObject
@property (nonatomic, copy) NSString *project_key;
@end

typedef NS_OPTIONS(NSUInteger, LiveCoreModule) {
    LiveCoreModuleCapture        = 1 << 0,      
    LiveCoreModuleLiveStreaming  = 1 << 1,      
    LiveCoreModuleInteract       = 1 << 2,      
    LiveCoreModuleTimorGame       = 1 << 3,      
};

typedef NS_OPTIONS(NSInteger, LCPipelineMode) {
    LCPipelineMode_LiveStreaming    = 1 << 0,
    LCPipelineMode_Interact         = 1 << 1,
    LCPipelineMode_TimorGame         = 1 << 2,
    LCPipelineMode_KTV              = 1 << 3,
};

typedef NS_ENUM(NSInteger, LCAudioCallbackType){
    LCAudioCallbackTypeMicrophone   = 0,
    LCAudioCallbackTypeInteract     = 1
};

#pragma mark - LiveCore
@interface LiveCore : NSObject
#pragma mark - 推流
@property (nonatomic, strong, readonly) LiveStreamSession *liveSession;
@property (nonatomic, copy) void(^statusChangedBlock)(LiveStreamSessionState state, LiveStreamErrorCode errCode);


@property (nonatomic, copy) void(^didCapturedAudioFrame)(void *data, int numberOfFrames, int channels, int64_t pts, LCAudioCallbackType type);

@property (nonatomic, copy) void(^pushStreamVideoFrameRateChangedBlock)(NSInteger frameRate);

@property (nonatomic, assign, readwrite) NSInteger reconnectCount;


@property (nonatomic, assign) LiveStreamLogLevel logLevel;
@property (nonatomic, assign) LiveCoreModule enabledModule;

@property (nonatomic, assign) BOOL enableExternalAU;

@property (nonatomic, assign) BOOL enableKeepDarkFrame;


@property (nonatomic, assign) BOOL enablePipelineKTVCamera;

@property (nonatomic, assign) BOOL enableMergeRtcExtraDataToLiveStream;

@property (nonatomic, assign) BOOL willCloseLivingRoom;

@property (nonatomic, assign) BOOL changeToFullInteractOnlySelf;

+ (NSString *)getSdkVersion;

- (instancetype)initWithMode:(LiveCoreModule)mode;

@property (nonatomic, copy) BOOL (^queryIsNeedStreamingCallback)(void);

- (void)setupLiveSessionWithConfig:(LiveStreamConfiguration *)config;

- (void) cleanUp;

- (void)setEnablePipelineMode:(LCPipelineMode)mode;
- (void)setDisablePipelineMode:(LCPipelineMode)mode;

- (LiveStreamSession *)getStreamSession DEPRECATED_MSG_ATTRIBUTE("Please use @property (nonatomic, strong, readonly) LiveStreamSession *liveSession;");

- (EAGLContext *)getEAGLContext;

- (void)startStreaming;

- (void)stopStreaming;

- (void)retryStreaming;

- (BOOL)isStreaming;

- (void)updateStreamingConfiguration:(NSDictionary *)sdkParams;

- (void)updateStreamingOutputSize:(CGSize)size;

- (void)updateStreamingBitrate:(NSInteger)defaultBitrate
                        minBit:(NSInteger)minBitrate
                        maxBit:(NSInteger)maxBitrate;

- (void)updateStreamingFrameRate:(NSInteger)frameRate;

- (void)updatePSNRStatisticsFrames:(NSInteger)statisticsFrames
                     periodSeconds:(NSInteger)periodSeconds
                            enable:(BOOL)enable;

- (void)pushEffectedVideoBuffer:(CVPixelBufferRef)pixelBufferRef
                        texture:(int32_t)textureId
                      andCMTime:(CMTime)pts;

- (void)pushEffectedVideoBufferAfterStarted:(CVPixelBufferRef) pixelBufferRef
                        texture:(int32_t) textureId
                                  andCMTime:(CMTime) pts;

- (void)startPushEffectedFrame;
- (void)stopPushEffectedFrame;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
           andTimestamp:(CMTime)pts;

- (void)pushAudioBuffer:(uint8_t *)data
             andDataLen:(size_t)size
      andInNumberFrames:(int)inNumberFrames
              andCMTime:(CMTime)pts;

- (void)setAudioMute:(BOOL)mute;

- (void) startPushDarkFrame;

- (void) stopPushDarkFrame;

- (int)sendSEIMsgWithKey:(NSString *)key value:(NSObject *)value repeatTimes:(NSInteger)repeatTimes keyFrameOnly:(BOOL)keyFrameOnly allowsCovered:(BOOL)allowsCovered;

- (int)sendSEIMsgWithKey:(NSString *)key value:(NSObject *)value repeatTimes:(NSInteger)repeatTimes keyFrameOnly:(BOOL)keyFrameOnly allowsCovered:(BOOL)allowsCovered timeGap:(int)timeGap;

- (int)sendSEIMsgWithKey:(NSString *)key value:(NSObject *)value repeatTimes:(NSInteger)repeatTimes;


- (void)pushRestart:(NSData *)jsonInfo DEPRECATED_MSG_ATTRIBUTE("Please use onLiveSdkParamsIssue");

- (void)onLiveSdkParamsIssue:(NSData *)jsonInfo;

- (void)setAudioPlayerMixMode:(LiveCoreAudioPlayerMode)mode;

- (void)setSeiCurrentShiftDiffTime:(int64_t)timeMs;

#pragma - mark DNSNodeSort
@property (nonatomic, copy) NSDictionary *(^shouldUpdateOptimumIPAddress)(NSString *host);


#pragma mark - log
@property (nonatomic,copy) void(^streamLogCallback)(NSDictionary *log);
@property (nonatomic,copy) void(^networkQualityCallback)(LiveCoreNetworkQuality networkQuality);
- (id)getStreamInfoForKey:(NSString *)name;

@property (nonatomic, assign) BOOL enableCheckingCameraRunningStatus;
#pragma mark - Debug Log
@property (nonatomic,copy) void(^debugLogBlock)(NSString *log);
-(void)debugLog:(NSString *)msg;

@end

