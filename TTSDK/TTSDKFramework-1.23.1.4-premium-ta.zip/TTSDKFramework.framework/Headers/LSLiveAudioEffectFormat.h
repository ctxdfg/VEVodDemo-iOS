
#import <Foundation/Foundation.h>


extern bool liveReCreateBuffer(float **out, int *currLength, int needLength);

#pragma mark - reverb format
@interface LSLiveAudioReverbFormat : NSObject <NSCopying>

@property (nonatomic, assign) float roomSize;
@property (nonatomic, assign) float hfDamping;
@property (nonatomic, assign) float stereoDepth;
@property (nonatomic, assign) float dry;
@property (nonatomic, assign) float wet;
@property (nonatomic, assign) float dryGainDB;
@property (nonatomic, assign) float wetGainDB;
@property (nonatomic, assign) BOOL dryOnly;
@property (nonatomic, assign) BOOL wetOnly;


- (instancetype)init;

@end


#pragma mark - reverb2 format
@interface LSLiveAudioReverb2Format : NSObject <NSCopying>

@property (nonatomic, assign) int sampleRate;
@property (nonatomic, assign) int oversamplefactor;
@property (nonatomic, assign) float ertolate;
@property (nonatomic, assign) float erefwet;
@property (nonatomic, assign) float dry;
@property (nonatomic, assign) float ereffactor;
@property (nonatomic, assign) float erefwidth;
@property (nonatomic, assign) float width;
@property (nonatomic, assign) float wet;
@property (nonatomic, assign) float wander;
@property (nonatomic, assign) float bassb;
@property (nonatomic, assign) float spin;
@property (nonatomic, assign) float inputlpf;
@property (nonatomic, assign) float basslpf;
@property (nonatomic, assign) float damplpf;
@property (nonatomic, assign) float outputlpf;
@property (nonatomic, assign) float rt60;
@property (nonatomic, assign) float delay;

- (instancetype)init;

@end

#pragma mark - equalizer format
@interface LSLiveAudioEqualizerFormat : NSObject <NSCopying>

@property (nonatomic) CGFloat preamp;

@property (nonatomic) CGFloat amp31;

@property (nonatomic) CGFloat amp63;

@property (nonatomic) CGFloat amp125;

@property (nonatomic) CGFloat amp250;

@property (nonatomic) CGFloat amp500;

@property (nonatomic) CGFloat amp1000;

@property (nonatomic) CGFloat amp2000;

@property (nonatomic) CGFloat amp4000;

@property (nonatomic) CGFloat amp8000;

@property (nonatomic) CGFloat amp16000;

@property (nonatomic) CGFloat freqWidth31;

@property (nonatomic) CGFloat freqWidth63;

@property (nonatomic) CGFloat freqWidth125;

@property (nonatomic) CGFloat freqWidth250;

@property (nonatomic) CGFloat freqWidth500;

@property (nonatomic) CGFloat freqWidth1000;

@property (nonatomic) CGFloat freqWidth2000;

@property (nonatomic) CGFloat freqWidth4000;

@property (nonatomic) CGFloat freqWidth8000;

@property (nonatomic) CGFloat freqWidth16000;

- (instancetype)init;

@end

#pragma mark - audio cleaner format
typedef NS_ENUM(NSUInteger, LSAudioCleanerTransformType) {
    MDCT_320X18 = 0,
    MDFT_512X320X18,
    MDFT_512X320X36,
    MDFT_512X384X36,
    MDFT_256X56X24,
    MDFT_32X32X12
};

@interface LSLiveAudioCleanerFormat : NSObject <NSCopying>

@property (nonatomic, assign) double sampleRate;

@property (nonatomic, assign) LSAudioCleanerTransformType transformType;

@property (nonatomic, assign) BOOL bAGC;

@property (nonatomic, assign) BOOL bANS;

@property (nonatomic, assign) BOOL bAEC;

@property (nonatomic, assign) BOOL bLimiter;

@property (nonatomic, assign) BOOL bHighNoiseMode;

@property (nonatomic, assign) BOOL bBeam;

- (instancetype)init;

@end

@interface LSLiveAudioExciterFormat : NSObject <NSCopying>

@property (nonatomic, assign) CGFloat gain;

@property (nonatomic, assign) NSInteger highpassfreq;

@end


@interface LSLiveAudioEffectData : NSObject

@property (nonatomic) LSLiveAudioReverbFormat*     reverbFormat;
@property (nonatomic) LSLiveAudioEqualizerFormat*  equalizerFormat;
@property (nonatomic) int                       stereoWidenWeightID;
@property (nonatomic) LSLiveAudioReverb2Format*    reverb2Format;
@property (nonatomic) NSTimeInterval            musicStartTime;
@property (nonatomic, assign)BOOL               enableCleaner;
@property (nonatomic, assign)BOOL               enableExciter;
@property (nonatomic, assign)BOOL               enableCompressor;
+ (instancetype) sharedInstance;

- (instancetype) init;

@end



